/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { SeatingPlan, ExamDetails, Room, BranchCohort, BranchPairing, StudentSearchResult } from '../types';
import {
  INITIAL_EXAM_DETAILS,
  INITIAL_ROOMS,
  INITIAL_BRANCH_COHORTS,
  INITIAL_BRANCH_PAIRINGS
} from '../data/sampleData';
import { generateSeatingPlan } from '../utils/seatingGenerator';

const STORAGE_KEYS = {
  EXAM: 'examseat_exam_details_v6',
  ROOMS: 'examseat_rooms_v6',
  COHORTS: 'examseat_branch_cohorts_v6',
  PAIRINGS: 'examseat_branch_pairings_v6',
  SECTION_RULE: 'examseat_section_rule_v6',
  CURRENT_PLAN: 'examseat_current_plan_v6'
};

export class SeatingApiService {
  static getExamDetails(): ExamDetails {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.EXAM);
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.warn(e);
    }
    return INITIAL_EXAM_DETAILS;
  }

  static saveExamDetails(details: ExamDetails) {
    localStorage.setItem(STORAGE_KEYS.EXAM, JSON.stringify(details));
  }

  static getRooms(): Room[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.ROOMS);
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.warn(e);
    }
    return INITIAL_ROOMS;
  }

  static saveRooms(rooms: Room[]) {
    localStorage.setItem(STORAGE_KEYS.ROOMS, JSON.stringify(rooms));
  }

  static getBranchCohorts(): BranchCohort[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.COHORTS);
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.warn(e);
    }
    return INITIAL_BRANCH_COHORTS;
  }

  static saveBranchCohorts(cohorts: BranchCohort[]) {
    localStorage.setItem(STORAGE_KEYS.COHORTS, JSON.stringify(cohorts));
  }

  static getBranchPairings(): BranchPairing[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.PAIRINGS);
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.warn(e);
    }
    return INITIAL_BRANCH_PAIRINGS;
  }

  static saveBranchPairings(pairings: BranchPairing[]) {
    localStorage.setItem(STORAGE_KEYS.PAIRINGS, JSON.stringify(pairings));
  }

  static getSectionRule(): 'mix' | 'separate' {
    const raw = localStorage.getItem(STORAGE_KEYS.SECTION_RULE);
    return raw === 'mix' ? 'mix' : 'separate';
  }

  static saveSectionRule(rule: 'mix' | 'separate') {
    localStorage.setItem(STORAGE_KEYS.SECTION_RULE, rule);
  }

  static getCurrentPlan(): SeatingPlan {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_PLAN);
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.warn(e);
    }

    const plan = generateSeatingPlan({
      examDetails: INITIAL_EXAM_DETAILS,
      branchCohorts: INITIAL_BRANCH_COHORTS,
      branchPairings: INITIAL_BRANCH_PAIRINGS,
      rooms: INITIAL_ROOMS,
      sectionRule: 'separate'
    });
    this.saveCurrentPlan(plan);
    return plan;
  }

  static async saveCurrentPlan(plan: SeatingPlan) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_PLAN, JSON.stringify(plan));
    
    // Save to SQLite backend via Express API
    try {
      await fetch('/api/plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(plan)
      });
    } catch (err) {
      console.info('SQLite backend notice:', err);
    }
  }

  static resetToDemoData(): SeatingPlan {
    localStorage.removeItem(STORAGE_KEYS.EXAM);
    localStorage.removeItem(STORAGE_KEYS.ROOMS);
    localStorage.removeItem(STORAGE_KEYS.COHORTS);
    localStorage.removeItem(STORAGE_KEYS.PAIRINGS);
    localStorage.removeItem(STORAGE_KEYS.SECTION_RULE);
    localStorage.removeItem(STORAGE_KEYS.CURRENT_PLAN);

    const plan = generateSeatingPlan({
      examDetails: INITIAL_EXAM_DETAILS,
      branchCohorts: INITIAL_BRANCH_COHORTS,
      branchPairings: INITIAL_BRANCH_PAIRINGS,
      rooms: INITIAL_ROOMS,
      sectionRule: 'separate'
    });
    this.saveCurrentPlan(plan);
    return plan;
  }

  static searchStudent(query: string, currentPlan: SeatingPlan): StudentSearchResult[] {
    const q = query.toLowerCase().trim();
    if (!q) return [];

    const results: StudentSearchResult[] = [];

    currentPlan.roomAllocations.forEach(room => {
      room.benches.forEach(bench => {
        if (
          bench.leftSeat &&
          (bench.leftSeat.regNo.toLowerCase().includes(q) ||
            bench.leftSeat.name.toLowerCase().includes(q))
        ) {
          results.push({
            student: bench.leftSeat,
            block: room.block,
            roomNumber: room.roomNumber,
            benchNumber: bench.benchNumber,
            columnNumber: bench.columnNumber,
            rowInColumn: bench.rowInColumn,
            position: 'Seat 1 (Left)'
          });
        }

        if (
          bench.rightSeat &&
          (bench.rightSeat.regNo.toLowerCase().includes(q) ||
            bench.rightSeat.name.toLowerCase().includes(q))
        ) {
          results.push({
            student: bench.rightSeat,
            block: room.block,
            roomNumber: room.roomNumber,
            benchNumber: bench.benchNumber,
            columnNumber: bench.columnNumber,
            rowInColumn: bench.rowInColumn,
            position: 'Seat 2 (Right)'
          });
        }
      });
    });

    return results;
  }
}
