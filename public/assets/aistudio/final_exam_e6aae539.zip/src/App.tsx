/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ExamSeatingForm } from './components/ExamSeatingForm';
import { SeatingResultsView } from './components/SeatingResultsView';
import { DownloadPrintSection } from './components/DownloadPrintSection';
import { OfficerLoginPage, OfficerUser } from './components/OfficerLoginPage';
import { OfficerRegisterPage } from './components/OfficerRegisterPage';
import { Footer } from './components/Footer';
import {
  SeatingPlan,
  ExamDetails,
  Room,
  BranchCohort,
  BranchPairing
} from './types';
import { SeatingApiService } from './services/api';

export default function App() {
  // Global persisted state
  const [currentPlan, setCurrentPlan] = useState<SeatingPlan>(() =>
    SeatingApiService.getCurrentPlan()
  );
  const [examDetails, setExamDetails] = useState<ExamDetails>(() =>
    SeatingApiService.getExamDetails()
  );
  const [branchCohorts, setBranchCohorts] = useState<BranchCohort[]>(() =>
    SeatingApiService.getBranchCohorts()
  );
  const [branchPairings, setBranchPairings] = useState<BranchPairing[]>(() =>
    SeatingApiService.getBranchPairings()
  );
  const [rooms, setRooms] = useState<Room[]>(() =>
    SeatingApiService.getRooms()
  );
  const [sectionRule, setSectionRule] = useState<'mix' | 'separate'>(() =>
    SeatingApiService.getSectionRule()
  );

  // Officer Authentication State
  const [officerUser, setOfficerUser] = useState<OfficerUser | null>(() => {
    try {
      const raw = localStorage.getItem('examseat_officer_session');
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.warn(e);
    }
    return null;
  });

  // Flow State: 1. 'register' -> 2. 'login' -> 3. 'main'
  const [currentView, setCurrentView] = useState<'register' | 'login' | 'main'>('register');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleRegisterSuccess = (officer: OfficerUser) => {
    setOfficerUser(officer);
    showToast(`✨ Account created for ${officer.name}! Redirecting to Sign In step...`);
    setCurrentView('login');
  };

  const handleLoginSuccess = (officer: OfficerUser) => {
    setOfficerUser(officer);
    setCurrentView('main');
    showToast(`✨ Welcome, Exam Officer ${officer.name} (${officer.role})`);
    setTimeout(() => {
      const formEl = document.getElementById('seating-form');
      if (formEl) formEl.scrollIntoView({ behavior: 'smooth' });
    }, 150);
  };

  const handleOfficerLogout = () => {
    localStorage.removeItem('examseat_officer_session');
    setOfficerUser(null);
    setCurrentView('login');
    showToast('Logged out of Exam Officer session successfully.');
  };

  const handleGenerateSuccess = (plan: SeatingPlan) => {
    setCurrentPlan(plan);
    setExamDetails(plan.examDetails);
    setBranchCohorts(plan.branchCohorts);
    setBranchPairings(plan.branchPairings);
    setSectionRule(plan.sectionRule);

    SeatingApiService.saveCurrentPlan(plan);
    SeatingApiService.saveExamDetails(plan.examDetails);
    SeatingApiService.saveBranchCohorts(plan.branchCohorts);
    SeatingApiService.saveBranchPairings(plan.branchPairings);
    SeatingApiService.saveSectionRule(plan.sectionRule);

    showToast('✨ Seating arrangement generated & saved for Pragati Engineering College halls!');
  };

  const handleResetDemo = () => {
    if (window.confirm('Reset all examination details, student cohorts, and 30-room block layouts to defaults?')) {
      const demoPlan = SeatingApiService.resetToDemoData();
      setCurrentPlan(demoPlan);
      setExamDetails(demoPlan.examDetails);
      setBranchCohorts(demoPlan.branchCohorts);
      setBranchPairings(demoPlan.branchPairings);
      setRooms(SeatingApiService.getRooms());
      setSectionRule('separate');
      showToast('Reset to Pragati demo dataset (4 blocks × 30 rooms).');
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF4F0] flex flex-col font-sans text-stone-800 antialiased selection:bg-[#6B2F2F] selection:text-[#F4D6C6]">
      
      {/* Top Navbar */}
      <Navbar
        onResetDemo={handleResetDemo}
        isOfficerLoggedIn={!!officerUser}
        officerName={officerUser?.name}
        onOpenRegisterPage={() => setCurrentView('register')}
        onOpenLoginPage={() => setCurrentView('login')}
        onOfficerLogout={handleOfficerLogout}
        currentView={currentView}
        onNavigateHome={() => setCurrentView('main')}
      />

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed top-24 right-4 z-50 p-4 bg-[#6B2F2F] text-white text-xs font-semibold rounded-2xl shadow-2xl border-2 border-[#D88C72] flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
          <span className="text-[#F4D6C6] font-medium">{toastMessage}</span>
          <button
            type="button"
            onClick={() => setToastMessage(null)}
            className="text-[#D88C72] hover:text-white ml-1 p-0.5 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* SPA Views Flow: 1. Registration -> 2. Login -> 3. Main Portal */}
      <main className="flex-1">
        {currentView === 'register' ? (
          <OfficerRegisterPage
            onRegisterSuccess={handleRegisterSuccess}
            onNavigateToLogin={() => setCurrentView('login')}
            onSkipToMain={() => setCurrentView('main')}
          />
        ) : currentView === 'login' ? (
          <OfficerLoginPage
            onLoginSuccess={handleLoginSuccess}
            onNavigateToRegister={() => setCurrentView('register')}
            onCancel={() => setCurrentView('main')}
          />
        ) : (
          <>
            {/* A. Hero Section */}
            <HeroSection
              currentPlan={currentPlan}
              isOfficerLoggedIn={!!officerUser}
              onOpenLoginPage={() => setCurrentView('login')}
            />

            {/* B. Main Exam Seating Generation Form (Strictly for Officer) */}
            <ExamSeatingForm
              initialExamDetails={examDetails}
              initialCohorts={branchCohorts}
              initialPairings={branchPairings}
              initialRooms={rooms}
              initialSectionRule={sectionRule}
              onGenerateSuccess={handleGenerateSuccess}
              isOfficerLoggedIn={!!officerUser}
              officerName={officerUser?.name}
              onOpenLoginPage={() => setCurrentView('login')}
            />

            {/* C. Seating Results & Interactive Bench Grid with Search */}
            <SeatingResultsView currentPlan={currentPlan} />

            {/* D. Download and Print Section */}
            <DownloadPrintSection currentPlan={currentPlan} />
          </>
        )}
      </main>

      {/* Clean College Footer */}
      <Footer />

    </div>
  );
}
