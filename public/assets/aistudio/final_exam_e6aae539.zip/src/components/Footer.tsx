/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowUp } from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#FAF4F0] border-t-2 border-[#D88C72]/40 py-8 text-xs text-[#3D2222]/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
        
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-white p-0.5 border border-[#6B2F2F] shadow-xs flex items-center justify-center shrink-0">
            <img
              src="/assets/aistudio/pragati_e6e0ac40.jpg"
              alt="Pragati Engineering College"
              className="w-full h-full object-contain rounded-full"
              onError={(e) => {
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          </div>
          <div>
            <span className="font-extrabold text-[#6B2F2F] text-sm block">
              Pragati Engineering College (Autonomous)
            </span>
            <span className="text-[#A44A3F] text-[11px] font-semibold">
              ExamSeat Pro • Academic Project Expo 2026
            </span>
          </div>
        </div>

        <p className="text-center md:text-left text-[#3D2222]/70 text-[11px]">
          Automatic Exam Seating System • 4 Blocks (30 Halls Each • 120 Total) • 4 Columns × 6 Benches
        </p>

        <button
          type="button"
          onClick={scrollToTop}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#F4D6C6] hover:bg-[#D88C72] text-[#6B2F2F] font-bold transition-colors cursor-pointer border border-[#D88C72]/60 shadow-xs"
        >
          <span>Back to Top</span>
          <ArrowUp className="w-3.5 h-3.5" />
        </button>

      </div>
    </footer>
  );
};
