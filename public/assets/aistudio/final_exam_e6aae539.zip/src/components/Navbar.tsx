/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Menu,
  X,
  RotateCcw,
  ShieldCheck,
  LogIn,
  LogOut,
  UserPlus,
  Award,
  Layers,
  GraduationCap
} from 'lucide-react';

interface NavbarProps {
  onResetDemo: () => void;
  isOfficerLoggedIn: boolean;
  officerName?: string;
  onOpenRegisterPage: () => void;
  onOpenLoginPage: () => void;
  onOfficerLogout: () => void;
  currentView: 'register' | 'login' | 'main';
  onNavigateHome: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onResetDemo,
  isOfficerLoggedIn,
  officerName,
  onOpenRegisterPage,
  onOpenLoginPage,
  onOfficerLogout,
  currentView,
  onNavigateHome
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    if (currentView !== 'main') {
      onNavigateHome();
      setTimeout(() => {
        const element = document.getElementById(id);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      }, 120);
      return;
    }

    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF4F0]/95 backdrop-blur-md border-b-2 border-[#D88C72]/40 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & College Brand Name */}
          <div
            onClick={() => onNavigateHome()}
            className="flex items-center gap-3 group cursor-pointer"
          >
            {/* Round Official College Crest Logo */}
            <div className="w-12 h-12 rounded-full bg-white p-1 border-2 border-[#6B2F2F] shadow-sm flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform ring-2 ring-[#D88C72]/50">
              <img
                src="/assets/aistudio/pragati_e6e0ac40.jpg"
                alt="Pragati Engineering College"
                className="w-full h-full object-contain rounded-full"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>

            <div>
              {/* College Tag Badge */}
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-black uppercase tracking-wider text-[#A44A3F] bg-[#F4D6C6] px-2 py-0.2 rounded-full border border-[#D88C72]/60">
                  Autonomous
                </span>
                <span className="text-[10px] font-bold text-[#6B2F2F]/80 hidden sm:inline">
                  NAAC 'A' Grade
                </span>
              </div>

              {/* Bold College Name */}
              <span className="text-base sm:text-lg font-black text-[#6B2F2F] tracking-tight leading-tight block uppercase drop-shadow-2xs">
                Pragati Engineering College
              </span>
              
              {/* System Sub-title */}
              <span className="text-[11px] text-[#A44A3F] font-bold tracking-normal block -mt-0.5">
                ExamSeat Pro <span className="text-[#3D2222]/60 font-medium">• Automatic Seating Arrangement</span>
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 text-xs font-bold text-[#6B2F2F]/80">
            <button
              type="button"
              onClick={() => onNavigateHome()}
              className={`px-3 py-2 rounded-lg transition-colors cursor-pointer ${
                currentView === 'main'
                  ? 'bg-[#F4D6C6] text-[#6B2F2F]'
                  : 'hover:text-[#6B2F2F] hover:bg-[#F4D6C6]/60'
              }`}
            >
              Main Portal
            </button>
            <button
              type="button"
              onClick={() => scrollTo('seating-form')}
              className="px-3 py-2 rounded-lg hover:text-[#6B2F2F] hover:bg-[#F4D6C6]/60 transition-colors cursor-pointer"
            >
              Seating Form & Blocks
            </button>
            <button
              type="button"
              onClick={() => scrollTo('seating-results')}
              className="px-3 py-2 rounded-lg hover:text-[#6B2F2F] hover:bg-[#F4D6C6]/60 transition-colors cursor-pointer"
            >
              Seating Results
            </button>
            <button
              type="button"
              onClick={() => scrollTo('student-search')}
              className="px-3 py-2 rounded-lg hover:text-[#6B2F2F] hover:bg-[#F4D6C6]/60 transition-colors cursor-pointer"
            >
              Find Student
            </button>
            <button
              type="button"
              onClick={() => scrollTo('download-reports')}
              className="px-3 py-2 rounded-lg hover:text-[#6B2F2F] hover:bg-[#F4D6C6]/60 transition-colors cursor-pointer"
            >
              Reports & Print
            </button>
          </nav>

          {/* Right Action Buttons: Step Pages & Auth Status */}
          <div className="hidden sm:flex items-center gap-2">
            
            {/* Demo Data Reset */}
            <button
              type="button"
              onClick={onResetDemo}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-[#6B2F2F] hover:text-[#A44A3F] bg-white hover:bg-[#F4D6C6]/60 border border-[#D88C72]/50 rounded-xl transition-colors cursor-pointer"
              title="Reset to default college expo sample dataset"
            >
              <RotateCcw className="w-3.5 h-3.5 text-[#A44A3F]" />
              <span>Reset Demo</span>
            </button>

            {/* Officer Status or Login/Register Links */}
            {isOfficerLoggedIn ? (
              <div className="flex items-center gap-2 bg-[#F4D6C6] border border-[#D88C72] pl-3 pr-1.5 py-1.5 rounded-xl shadow-xs">
                <ShieldCheck className="w-4 h-4 text-[#6B2F2F]" />
                <span className="text-xs font-bold text-[#6B2F2F] truncate max-w-[130px]">
                  {officerName || 'Exam Officer'}
                </span>
                <button
                  type="button"
                  onClick={onOfficerLogout}
                  className="inline-flex items-center gap-1 px-2.5 py-1 bg-white hover:bg-[#6B2F2F] text-[#6B2F2F] hover:text-white rounded-lg text-xs font-bold transition-colors cursor-pointer ml-1"
                  title="Sign out of Officer session"
                >
                  <LogOut className="w-3 h-3" />
                  <span>Logout</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-1.5">
                {/* 1. Register Link */}
                <button
                  type="button"
                  onClick={onOpenRegisterPage}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                    currentView === 'register'
                      ? 'bg-[#A44A3F] text-white ring-2 ring-[#6B2F2F]'
                      : 'bg-white hover:bg-[#F4D6C6] text-[#6B2F2F] border border-[#D88C72]/60'
                  }`}
                >
                  <UserPlus className="w-3.5 h-3.5 text-[#A44A3F]" />
                  <span>Register</span>
                </button>

                {/* 2. Login Link */}
                <button
                  type="button"
                  onClick={onOpenLoginPage}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                    currentView === 'login'
                      ? 'bg-[#A44A3F] text-white ring-2 ring-[#6B2F2F]'
                      : 'bg-[#6B2F2F] hover:bg-[#A44A3F] text-white shadow-xs'
                  }`}
                >
                  <LogIn className="w-3.5 h-3.5 text-[#F4D6C6]" />
                  <span>Sign In</span>
                </button>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex lg:hidden items-center gap-2">
            {!isOfficerLoggedIn ? (
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={onOpenRegisterPage}
                  className="px-2 py-1 text-xs font-bold text-[#6B2F2F] bg-white border border-[#D88C72] rounded-lg"
                >
                  Register
                </button>
                <button
                  type="button"
                  onClick={onOpenLoginPage}
                  className="px-2.5 py-1 text-xs font-bold text-white bg-[#6B2F2F] rounded-lg"
                >
                  Sign In
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={onOfficerLogout}
                className="p-1.5 text-[#6B2F2F] bg-[#F4D6C6] rounded-lg"
                title="Logout"
              >
                <LogOut className="w-4 h-4" />
              </button>
            )}

            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-[#6B2F2F] hover:text-[#A44A3F] hover:bg-[#F4D6C6]/60 rounded-lg cursor-pointer"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Dropdown Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#FAF4F0] border-b border-[#D88C72]/40 px-4 pt-2 pb-4 space-y-1 shadow-lg text-xs font-semibold text-[#6B2F2F]">
          <div className="pb-2 border-b border-[#D88C72]/30 flex items-center justify-between">
            <span className="font-extrabold text-[11px] uppercase tracking-wider text-[#A44A3F]">
              Pragati Seating Portal
            </span>
            <button
              type="button"
              onClick={onResetDemo}
              className="text-[11px] font-bold text-[#6B2F2F] underline"
            >
              Reset Demo
            </button>
          </div>
          <button
            type="button"
            onClick={() => onNavigateHome()}
            className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#F4D6C6]"
          >
            Main Seating Portal
          </button>
          <button
            type="button"
            onClick={() => scrollTo('seating-form')}
            className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#F4D6C6]"
          >
            Seating Form & Blocks
          </button>
          <button
            type="button"
            onClick={() => scrollTo('seating-results')}
            className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#F4D6C6]"
          >
            Seating Results (4 Columns)
          </button>
          <button
            type="button"
            onClick={() => scrollTo('student-search')}
            className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#F4D6C6]"
          >
            Find Student
          </button>
          <button
            type="button"
            onClick={() => scrollTo('download-reports')}
            className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#F4D6C6]"
          >
            Reports & Print
          </button>
        </div>
      )}
    </header>
  );
};
