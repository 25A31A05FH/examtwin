/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  UserCheck,
  KeyRound,
  ArrowLeft,
  LogIn,
  AlertCircle,
  Eye,
  EyeOff,
  Sparkles,
  Award,
  UserPlus
} from 'lucide-react';

export interface OfficerUser {
  id: string;
  name: string;
  role: string;
  email: string;
  department: string;
  loginTime: string;
}

interface OfficerLoginPageProps {
  onLoginSuccess: (officer: OfficerUser) => void;
  onNavigateToRegister: () => void;
  onCancel: () => void;
}

export const OfficerLoginPage: React.FC<OfficerLoginPageProps> = ({
  onLoginSuccess,
  onNavigateToRegister,
  onCancel
}) => {
  const [officerId, setOfficerId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Default demo credentials
  const DEMO_OFFICER_ID = 'officer@pragati.ac.in';
  const DEMO_PASSWORD = 'pragati2026';

  const handleQuickFill = () => {
    setOfficerId(DEMO_OFFICER_ID);
    setPassword(DEMO_PASSWORD);
    setErrorMessage(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const inputId = officerId.trim().toLowerCase();
    const inputPass = password.trim();

    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);

      // Check in registered users list first
      let matchedUser: OfficerUser | null = null;
      try {
        const storedUsersRaw = localStorage.getItem('examseat_registered_officers');
        if (storedUsersRaw) {
          const registeredList: OfficerUser[] = JSON.parse(storedUsersRaw);
          const found = registeredList.find(
            u => u.email.toLowerCase() === inputId || u.id.toLowerCase() === inputId
          );
          if (found) {
            matchedUser = found;
          }
        }
      } catch (err) {
        console.warn(err);
      }

      // Default demo credentials & common shortcuts
      const validIds = [
        'officer@pragati.ac.in',
        'officer@examcell.edu',
        'pec-exam-2026',
        'officer-2026',
        'admin',
        'examcell',
        'dr.ramanamurthy@pragati.ac.in'
      ];
      const validPasswords = ['pragati2026', 'examseat2026', 'admin123', 'officer2026'];

      if (matchedUser) {
        const sessionOfficer: OfficerUser = {
          ...matchedUser,
          loginTime: new Date().toISOString()
        };
        localStorage.setItem('examseat_officer_session', JSON.stringify(sessionOfficer));
        onLoginSuccess(sessionOfficer);
      } else if (validIds.includes(inputId) && (validPasswords.includes(inputPass) || inputPass.length >= 6)) {
        const officer: OfficerUser = {
          id: 'PEC-EXAM-01',
          name: 'Dr. K. V. Raman',
          role: 'Chief Controller of Examinations',
          email: inputId.includes('@') ? inputId : 'officer@pragati.ac.in',
          department: 'Academic & Examination Section',
          loginTime: new Date().toISOString()
        };

        localStorage.setItem('examseat_officer_session', JSON.stringify(officer));
        onLoginSuccess(officer);
      } else {
        setErrorMessage('Invalid Officer Email / ID or Password. Click "Quick Fill Demo" or Register a new account.');
      }
    }, 400);
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 py-8 sm:py-12">
      <div className="w-full max-w-md">
        
        {/* Back Link */}
        <div className="flex items-center justify-between mb-4">
          <button
            type="button"
            onClick={onCancel}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-[#6B2F2F] hover:text-[#A44A3F] transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 text-[#A44A3F]" />
            <span>Back to Portal</span>
          </button>

          <button
            type="button"
            onClick={onNavigateToRegister}
            className="inline-flex items-center gap-1 text-xs font-bold text-[#6B2F2F] hover:text-[#A44A3F] transition-colors cursor-pointer underline underline-offset-2"
          >
            <UserPlus className="w-3.5 h-3.5 text-[#A44A3F]" />
            <span>Register as Officer</span>
          </button>
        </div>

        {/* Main Login Card */}
        <div className="bg-white rounded-3xl border-2 border-[#D88C72]/60 shadow-xl overflow-hidden">
          
          {/* Highlighted College Header Banner */}
          <div className="bg-gradient-to-r from-[#6B2F2F] via-[#A44A3F] to-[#6B2F2F] text-white p-6 text-center relative overflow-hidden">
            
            {/* College Logo */}
            <div className="flex justify-center mb-2.5">
              <div className="w-18 h-18 sm:w-20 sm:h-20 rounded-full bg-white p-1 shadow-lg border-2 border-[#F4D6C6] flex items-center justify-center ring-4 ring-[#FAF4F0]/20">
                <img
                  src="/assets/aistudio/pragati_e6e0ac40.jpg"
                  alt="Pragati Engineering College Logo"
                  className="w-full h-full object-contain rounded-full"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              </div>
            </div>

            <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#FAF4F0]/20 backdrop-blur-xs text-[#F4D6C6] text-[10px] font-bold tracking-widest uppercase mb-1">
              <Award className="w-3 h-3 text-[#F4D6C6]" />
              <span>Autonomous • NAAC 'A' Grade</span>
            </div>

            <h1 className="text-lg sm:text-xl font-black tracking-tight text-white uppercase drop-shadow-xs">
              Pragati Engineering College
            </h1>
            <p className="text-xs text-[#F4D6C6] font-semibold mt-0.5">
              Office of the Controller of Examinations
            </p>
            <div className="mt-2 text-[10px] font-bold tracking-wider uppercase text-[#FAF4F0]/90 bg-black/20 py-0.5 px-3 rounded-full inline-block">
              Step 2: Exam Officer Sign In
            </div>
          </div>

          {/* Form Area */}
          <div className="p-6 sm:p-7 space-y-5">
            
            <div className="flex items-center justify-between pb-3 border-b border-[#D88C72]/30">
              <div>
                <h2 className="font-extrabold text-[#6B2F2F] text-base flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-[#A44A3F]" />
                  <span>Officer Authentication</span>
                </h2>
                <p className="text-xs text-[#3D2222]/70">
                  Enter your credentials to access hall allocation & seating algorithms
                </p>
              </div>

              {/* Quick Fill Button */}
              <button
                type="button"
                onClick={handleQuickFill}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-[#FAF4F0] hover:bg-[#F4D6C6] text-[#6B2F2F] border border-[#D88C72]/60 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-2xs hover:scale-102"
              >
                <Sparkles className="w-3 h-3 text-[#A44A3F]" />
                <span>Quick Fill</span>
              </button>
            </div>

            {/* Error Message */}
            {errorMessage && (
              <div className="p-3 bg-[#F4D6C6] border border-[#A44A3F] rounded-xl text-xs font-semibold text-[#6B2F2F] flex items-center gap-2 animate-in fade-in">
                <AlertCircle className="w-4 h-4 text-[#A44A3F] shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Officer ID / Email */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#6B2F2F] flex items-center gap-1.5">
                  <UserCheck className="w-3.5 h-3.5 text-[#A44A3F]" />
                  <span>Officer Email or Staff ID *</span>
                </label>
                <input
                  type="text"
                  required
                  value={officerId}
                  onChange={(e) => setOfficerId(e.target.value)}
                  placeholder="officer@pragati.ac.in or PEC-EXAM-2026"
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#FAF4F0]/60 border border-[#D88C72]/60 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#A44A3F]/30 focus:border-[#6B2F2F] text-[#3D2222] font-medium"
                />
              </div>

              {/* Password */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#6B2F2F] flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-[#A44A3F]" />
                  <span>Password *</span>
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter password"
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#FAF4F0]/60 border border-[#D88C72]/60 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#A44A3F]/30 focus:border-[#6B2F2F] text-[#3D2222] font-medium pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#A44A3F] hover:text-[#6B2F2F] p-1 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 px-4 bg-[#6B2F2F] hover:bg-[#A44A3F] active:bg-[#6B2F2F] text-white font-extrabold text-sm rounded-xl shadow-md shadow-[#6B2F2F]/25 hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70 mt-2"
              >
                {isLoading ? (
                  <span className="inline-flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Verifying Credentials...</span>
                  </span>
                ) : (
                  <>
                    <LogIn className="w-4 h-4 text-[#F4D6C6]" />
                    <span>Sign In & Open Seating Portal</span>
                  </>
                )}
              </button>
            </form>

            {/* Bottom Links */}
            <div className="pt-4 border-t border-[#D88C72]/30 space-y-3 text-center">
              <p className="text-xs text-[#3D2222]/80 font-medium">
                Don't have an Officer account?{' '}
                <button
                  type="button"
                  onClick={onNavigateToRegister}
                  className="font-extrabold text-[#6B2F2F] hover:text-[#A44A3F] underline underline-offset-2 cursor-pointer ml-1"
                >
                  Register here &rarr;
                </button>
              </p>

              <div>
                <button
                  type="button"
                  onClick={onCancel}
                  className="text-[11px] font-bold text-[#A44A3F] hover:text-[#6B2F2F] hover:underline cursor-pointer"
                >
                  Continue to Main Seating Portal (Expo View)
                </button>
              </div>
            </div>

          </div>
        </div>

        {/* Security and College Stamp */}
        <div className="mt-4 text-center space-y-1">
          <p className="text-[11px] font-semibold text-[#6B2F2F]/80">
            PRAGATI ENGINEERING COLLEGE (AUTONOMOUS) • Surampalem
          </p>
          <p className="text-[10px] text-[#A44A3F]">
            Automatic Seating Arrangement System • 4 Blocks (30 Rooms Each)
          </p>
        </div>

      </div>
    </div>
  );
};
