/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  UserPlus,
  Mail,
  Building2,
  BadgeCheck,
  CheckCircle2,
  ArrowRight,
  Eye,
  EyeOff,
  Sparkles,
  Award
} from 'lucide-react';
import { OfficerUser } from './OfficerLoginPage';

interface OfficerRegisterPageProps {
  onRegisterSuccess: (officer: OfficerUser) => void;
  onNavigateToLogin: () => void;
  onSkipToMain: () => void;
}

export const OfficerRegisterPage: React.FC<OfficerRegisterPageProps> = ({
  onRegisterSuccess,
  onNavigateToLogin,
  onSkipToMain
}) => {
  const [fullName, setFullName] = useState('');
  const [officerId, setOfficerId] = useState('');
  const [email, setEmail] = useState('');
  const [department, setDepartment] = useState('Examination Cell');
  const [role, setRole] = useState('Chief Controller of Examinations');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleQuickFill = () => {
    setFullName('Dr. K. V. Raman');
    setOfficerId('PEC-EXAM-2026');
    setEmail('officer@pragati.ac.in');
    setDepartment('Examination Cell');
    setRole('Chief Controller of Examinations');
    setPassword('pragati2026');
    setConfirmPassword('pragati2026');
    setErrorMessage(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!fullName.trim()) {
      setErrorMessage('Please enter your full name.');
      return;
    }
    if (!officerId.trim()) {
      setErrorMessage('Please enter your Officer or Faculty ID.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setErrorMessage('Please enter a valid official college email address.');
      return;
    }
    if (password.length < 6) {
      setErrorMessage('Password must be at least 6 characters long.');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMessage('Passwords do not match. Please verify your password.');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);

      const newOfficer: OfficerUser = {
        id: officerId.trim().toUpperCase(),
        name: fullName.trim(),
        role: role,
        email: email.trim().toLowerCase(),
        department: department,
        loginTime: new Date().toISOString()
      };

      // Store in localStorage
      try {
        const storedUsersRaw = localStorage.getItem('examseat_registered_officers');
        const storedUsers: OfficerUser[] = storedUsersRaw ? JSON.parse(storedUsersRaw) : [];
        storedUsers.push(newOfficer);
        localStorage.setItem('examseat_registered_officers', JSON.stringify(storedUsers));
        localStorage.setItem('examseat_officer_session', JSON.stringify(newOfficer));
      } catch (err) {
        console.warn('Failed to save to localStorage', err);
      }

      onRegisterSuccess(newOfficer);
    }, 450);
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 py-8 sm:py-12">
      <div className="w-full max-w-lg">
        
        {/* Main Card */}
        <div className="bg-white rounded-3xl border-2 border-[#D88C72]/60 shadow-xl overflow-hidden">
          
          {/* Highlighted College Header Banner */}
          <div className="bg-gradient-to-r from-[#6B2F2F] via-[#A44A3F] to-[#6B2F2F] text-white p-6 sm:p-7 text-center relative overflow-hidden">
            {/* Background Decorative Rings */}
            <div className="absolute -top-10 -right-10 w-36 h-36 rounded-full bg-white/5 pointer-events-none" />
            <div className="absolute -bottom-10 -left-10 w-36 h-36 rounded-full bg-white/5 pointer-events-none" />

            {/* Official College Logo */}
            <div className="flex justify-center mb-3">
              <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-white p-1.5 shadow-lg border-2 border-[#F4D6C6] flex items-center justify-center ring-4 ring-[#FAF4F0]/20">
                <img
                  src="/assets/aistudio/pragati_e6e0ac40.jpg"
                  alt="Pragati Engineering College Logo"
                  className="w-full h-full object-contain rounded-full"
                  onError={(e) => {
                    // Fallback to text icon if path issue
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              </div>
            </div>

            {/* Highlighted College Name */}
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-[#FAF4F0]/20 backdrop-blur-xs text-[#F4D6C6] text-[11px] font-bold tracking-widest uppercase mb-1">
              <Award className="w-3.5 h-3.5 text-[#F4D6C6]" />
              <span>Autonomous Institution • Accredited by NAAC 'A' Grade</span>
            </div>

            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white drop-shadow-xs uppercase">
              Pragati Engineering College
            </h1>
            <p className="text-xs sm:text-sm text-[#F4D6C6] font-medium mt-0.5">
              Office of the Controller of Examinations
            </p>
            <div className="mt-2 text-[11px] font-bold tracking-wider uppercase text-[#FAF4F0]/90 bg-black/20 py-1 px-3 rounded-full inline-block">
              ExamSeat Pro – Officer Registration
            </div>
          </div>

          {/* Form Section */}
          <div className="p-6 sm:p-8 space-y-5">
            
            <div className="flex items-center justify-between pb-3 border-b border-[#D88C72]/30">
              <div>
                <h2 className="font-extrabold text-[#6B2F2F] text-base sm:text-lg flex items-center gap-2">
                  <UserPlus className="w-5 h-5 text-[#A44A3F]" />
                  <span>Step 1: Create Officer Account</span>
                </h2>
                <p className="text-xs text-[#3D2222]/70">
                  Register to configure examination halls, branch pairing & bench allotments
                </p>
              </div>

              {/* Quick Fill Button */}
              <button
                type="button"
                onClick={handleQuickFill}
                className="inline-flex items-center gap-1 px-3 py-1.5 bg-[#FAF4F0] hover:bg-[#F4D6C6] text-[#6B2F2F] border border-[#D88C72]/60 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-2xs hover:scale-102"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#A44A3F]" />
                <span>Quick Fill</span>
              </button>
            </div>

            {/* Error Message */}
            {errorMessage && (
              <div className="p-3 bg-[#F4D6C6] border border-[#A44A3F] rounded-xl text-xs font-semibold text-[#6B2F2F] flex items-center gap-2 animate-in fade-in">
                <span className="w-2 h-2 rounded-full bg-[#6B2F2F]" />
                <span>{errorMessage}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Full Name */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#6B2F2F] flex items-center gap-1.5">
                  <BadgeCheck className="w-3.5 h-3.5 text-[#A44A3F]" />
                  <span>Full Name & Title *</span>
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Dr. K. V. Raman"
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#FAF4F0]/60 border border-[#D88C72]/60 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#A44A3F]/30 focus:border-[#6B2F2F] text-[#3D2222] font-medium"
                />
              </div>

              {/* Row: Officer ID & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#6B2F2F] flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#A44A3F]" />
                    <span>Officer / Faculty ID *</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={officerId}
                    onChange={(e) => setOfficerId(e.target.value)}
                    placeholder="e.g. PEC-EXAM-2026"
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#FAF4F0]/60 border border-[#D88C72]/60 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#A44A3F]/30 focus:border-[#6B2F2F] text-[#3D2222] font-medium uppercase"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#6B2F2F] flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-[#A44A3F]" />
                    <span>College Email *</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="officer@pragati.ac.in"
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#FAF4F0]/60 border border-[#D88C72]/60 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#A44A3F]/30 focus:border-[#6B2F2F] text-[#3D2222] font-medium"
                  />
                </div>
              </div>

              {/* Row: Department & Designation */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#6B2F2F] flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-[#A44A3F]" />
                    <span>Department *</span>
                  </label>
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#FAF4F0]/60 border border-[#D88C72]/60 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#A44A3F]/30 focus:border-[#6B2F2F] text-[#3D2222] font-medium"
                  >
                    <option value="Examination Cell">Examination Cell</option>
                    <option value="Computer Science & Engineering">CSE Department</option>
                    <option value="Electronics & Communication">ECE Department</option>
                    <option value="Electrical & Electronics">EEE Department</option>
                    <option value="Information Technology">IT Department</option>
                    <option value="Mechanical Engineering">Mechanical Dept</option>
                    <option value="Civil Engineering">Civil Dept</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#6B2F2F] flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5 text-[#A44A3F]" />
                    <span>Designation *</span>
                  </label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#FAF4F0]/60 border border-[#D88C72]/60 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#A44A3F]/30 focus:border-[#6B2F2F] text-[#3D2222] font-medium"
                  >
                    <option value="Chief Controller of Examinations">Chief Controller of Exams</option>
                    <option value="Controller of Examinations">Controller of Exams</option>
                    <option value="Assistant Controller of Examinations">Assistant Controller</option>
                    <option value="Chief Superintendent">Chief Superintendent</option>
                    <option value="Senior Invigilator / Faculty">Senior Invigilator</option>
                  </select>
                </div>
              </div>

              {/* Password & Confirm Password */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#6B2F2F] flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-[#A44A3F]" />
                    <span>Password *</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Min 6 characters"
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#FAF4F0]/60 border border-[#D88C72]/60 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#A44A3F]/30 focus:border-[#6B2F2F] text-[#3D2222] font-medium pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[#A44A3F] hover:text-[#6B2F2F] p-1"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#6B2F2F] flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#A44A3F]" />
                    <span>Confirm Password *</span>
                  </label>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Repeat password"
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#FAF4F0]/60 border border-[#D88C72]/60 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#A44A3F]/30 focus:border-[#6B2F2F] text-[#3D2222] font-medium"
                  />
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 px-4 bg-[#6B2F2F] hover:bg-[#A44A3F] active:bg-[#6B2F2F] text-white font-extrabold text-sm rounded-xl shadow-md shadow-[#6B2F2F]/25 hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70 mt-2"
              >
                {isLoading ? (
                  <span className="inline-flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Registering Officer Profile...</span>
                  </span>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4 text-[#F4D6C6]" />
                    <span>Complete Registration & Continue</span>
                    <ArrowRight className="w-4 h-4 text-[#F4D6C6]" />
                  </>
                )}
              </button>
            </form>

            {/* Bottom Links: Already Registered -> Login */}
            <div className="pt-4 border-t border-[#D88C72]/30 space-y-3 text-center">
              <p className="text-xs text-[#3D2222]/80 font-medium">
                Already registered with Pragati Examination Cell?{' '}
                <button
                  type="button"
                  onClick={onNavigateToLogin}
                  className="font-extrabold text-[#6B2F2F] hover:text-[#A44A3F] underline underline-offset-2 cursor-pointer ml-1"
                >
                  Sign In to Exam Portal &rarr;
                </button>
              </p>

              <div>
                <button
                  type="button"
                  onClick={onSkipToMain}
                  className="text-[11px] font-bold text-[#A44A3F] hover:text-[#6B2F2F] hover:underline cursor-pointer"
                >
                  Skip to Seating Arrangement View (Expo Demo Mode)
                </button>
              </div>
            </div>

          </div>
        </div>

        {/* Security and College Stamp */}
        <div className="mt-4 text-center space-y-1">
          <p className="text-[11px] font-semibold text-[#6B2F2F]/80">
            PRAGATI ENGINEERING COLLEGE (AUTONOMOUS) • 1-378, ADB Road, Surampalem, Near Kakinada
          </p>
          <p className="text-[10px] text-[#A44A3F]">
            Automatic Seating Arrangement System • 4 Blocks (30 Rooms Each) • 4 Columns × 6 Benches
          </p>
        </div>

      </div>
    </div>
  );
};
