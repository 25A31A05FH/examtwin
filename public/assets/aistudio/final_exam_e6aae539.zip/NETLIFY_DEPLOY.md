# Deploying ExamSeat Pro to Netlify

**ExamSeat Pro** (Pragati Engineering College – Automatic Exam Seating Arrangement System) is configured and ready for 1-click deployment on [Netlify](https://www.netlify.com/).

---

## 🚀 Method 1: Git Integration (Recommended)

1. **Push your repository** to GitHub, GitLab, or Bitbucket.
2. Log in to [Netlify](https://app.netlify.com/).
3. Click **"Add new site"** > **"Import an existing project"**.
4. Choose your Git provider and select this repository.
5. Netlify will automatically detect `netlify.toml` and populate the settings:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
   - **Base directory:** *(leave empty or set to `/`)*
6. Click **"Deploy site"**. Your site will build in ~30 seconds and receive a live `.netlify.app` URL.

---

## 📦 Method 2: Manual Deploy / Netlify Drop (No Git required)

1. Build the production folder locally:
   ```bash
   npm run build
   ```
2. Log in to [Netlify Drop](https://app.netlify.com/drop).
3. Drag and drop the generated `dist/` folder into the Netlify Drop area.
4. Your application will be deployed instantly!

---

## 💻 Method 3: Netlify CLI

1. Install Netlify CLI if you haven't:
   ```bash
   npm install -g netlify-cli
   ```
2. Build the application:
   ```bash
   npm run build
   ```
3. Deploy to production:
   ```bash
   ntl deploy --prod --dir=dist
   ```

---

## ⚙️ Configuration Details Included

- `netlify.toml`: Defines build command (`npm run build`), publish directory (`dist`), and single-page application routing (`/* -> /index.html 200`).
- `public/_redirects`: Provides Netlify's standard fallback to prevent 404 errors when refreshing pages or navigating directly.
- **Client-Side Persistence:** When deployed statically to Netlify, the app stores officer registrations, credentials, and generated seating arrangements in the browser's persistent `localStorage`. All calculations, visual layouts, search, CSV/Excel imports, and PDF/Excel downloads function completely client-side without needing a separate backend server!
